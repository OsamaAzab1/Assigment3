import java.util.ArrayList;

public class GroceryList {
    private ArrayList<GroceryItemOrder> items;
    private int size;

    public GroceryList() {
        this.items = new ArrayList<GroceryItemOrder>();
        this.size = 0;
    }

    public void add(GroceryItemOrder item) {
        if (size < 10) {
            items.add(item);
            size++;
        }
    }

    public double getTotalCost() {
        double total = 0;
        for (GroceryItemOrder item : items) {
            total += item.getCost();
        }
        return total;
    }
}
