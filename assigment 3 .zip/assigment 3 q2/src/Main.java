import java.util.ArrayList;
public class Main {
    public static void main(String[] args){
        ArrayList<Integer>x=new ArrayList<>();
        x.add(4);
        x.add(2);
        x.add(3);
        System.out.println(max(x));
        sort(x);
        System.out.println(x.toString());
        GroceryItemOrder g1=new GroceryItemOrder("chips",10);
        GroceryItemOrder g2=new GroceryItemOrder("Milk",20);
        GroceryList l1=new GroceryList();
        l1.add(g1);
        l1.add(g2);
        double total_cost=l1.getTotalCost();
        System.out.println(total_cost);





    }
    public static Integer max(ArrayList<Integer> list) {
        if (list == null || list.size() == 0) {
            return null;
        }
        int max = list.get(0);
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i) > max) {
                max = list.get(i);
            }
        }
       return max;
    }
    public static void sort(ArrayList<Integer> list) {
        if (list == null || list.size() == 0) {
            return;
        }
        int n = list.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (list.get(j) > list.get(j + 1)) {
                    int temp = list.get(j);
                    list.set(j, list.get(j + 1));
                    list.set(j + 1, temp);
                }
            }
        }
    }



}

