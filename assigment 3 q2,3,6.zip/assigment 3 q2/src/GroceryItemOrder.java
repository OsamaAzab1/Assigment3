public class GroceryItemOrder {
    public String name;
    public int quantity;
    public double pricePerUnit;

    public GroceryItemOrder(String name, double pricePerUnit) {
        this.name = name;
        this.quantity = 0;
        this.pricePerUnit = pricePerUnit;
    }

    public double getCost(int quantity,double pricePerUnit) {

        return quantity * pricePerUnit;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
